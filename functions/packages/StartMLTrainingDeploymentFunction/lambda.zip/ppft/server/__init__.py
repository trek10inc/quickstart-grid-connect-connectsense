"""
(Remote) ppft servers can be created with ``ppserver`` (or with
``python -m ppserver``), and then jobs can be distributed to remote
workers. See ``--help`` for more details on how to configure a server.
"""
